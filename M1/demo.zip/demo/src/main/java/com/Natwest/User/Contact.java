package com.Natwest.User;


public class Contact {

	int contactId;
	String email;
	int userId;
}
