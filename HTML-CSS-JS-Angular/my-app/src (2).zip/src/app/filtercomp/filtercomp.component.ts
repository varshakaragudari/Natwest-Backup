import { Component ,Input } from '@angular/core';

@Component({
  selector: 'app-filtercomp',
  templateUrl: './filtercomp.component.html',
  styleUrls: ['./filtercomp.component.css']
})
export class FiltercompComponent {


}
